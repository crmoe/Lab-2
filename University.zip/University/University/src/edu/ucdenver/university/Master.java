package edu.ucdenver.university;

public class Master {
}
