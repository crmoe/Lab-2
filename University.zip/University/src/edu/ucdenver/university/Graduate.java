package edu.ucdenver.university;
import java.time.LocalDate;


public class Graduate extends Student{

    public Graduate(String name, LocalDate dob) {
       super(name,dob);

    }

    @Override
    public final String getStanding(){
        return "edu.ucdenver.university.Undergraduate";

    };
}
